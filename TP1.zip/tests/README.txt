Set de instancias de prueba con sus respectivos ranking de Page:
- test_aleatorio: Un grafo aleatorio de 5x5 con los arcos ordenados según el par (i, j). (p = 0.85)
- test_aleatorio_desordenado: El mismo grafo de test_aleatorio pero con los arcos sin estar ordenados por (i, j). (p = 0.76)
- test_trivial: Grafo trivial (1 nodo) (p = 0.3)
- test_completo: Grafo completo de 5 nodos (p = 0.5)
- test_sin_links: Grafo de 5 nodos sin arcos (p = 0.64)
- test_15_segundos: Grafo que debería tardar alrededor de 15 segundos con una implementación de matriz esparsa y eliminación gaussiana. (p = 0.9)
- test_30_segundos: Grafo que debería tardar alrededor de 30 segundos con una implementación de matriz esparsa y eliminación gaussiana. (p = 0.8)

(*) Todos los resultados tienen como primera linea el p que se utilizó.

